Project Name: Smart-Motion-ESP01
Project Version: #7da97a6a
Project Url: https://www.flux.ai/pranjal-joshi/smart-motion-esp01

Project Description:
ESP01 + RCWL 0516 based motion sensor compatible with Alexa


