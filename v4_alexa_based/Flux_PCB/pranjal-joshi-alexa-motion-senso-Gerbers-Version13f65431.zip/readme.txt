Project Name: Alexa Motion Senso
Project Version: #13f65431
Project Url: https://www.flux.ai/pranjal-joshi/alexa-motion-senso

Project Description:
ESP8266 (NodeMCU) & RCWL-0516/PIR based motion sensor for alexa to trigger routines and control smart home devices from it


